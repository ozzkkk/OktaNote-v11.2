# Yakıt Takip v5 — Offline PWA

Bu sürüm, v4’teki gerçek harita/istasyon özelliklerini korur ve üzerine **service worker + çevrimdışı uygulama kabuğu** ekler. Tailwind artık CDN’de tarayıcıda derlenmez; önceden derlenmiş yerel `assets/tailwind.css` kullanılır. Yazı tipleri ve ikonlar da yereldir.

## Klasör yapısı

```text
yakit-takip-v5-pwa/
├── index.html              # Uygulama
├── sw.js                   # Service worker (HTTPS/localhost gerekir)
├── manifest.webmanifest    # PWA manifesti
├── serve.py                # İsteğe bağlı yerel test sunucusu
├── netlify.toml            # Netlify başlıkları
└── assets/
    ├── tailwind.css        # Önceden derlenmiş Tailwind
    ├── fonts.css           # Inter (yerel)
    ├── icons.css           # Font Awesome alt kümesi (yerel)
    ├── leaflet.css/js      # Leaflet 1.9.4 (yerel)
    ├── pwa.css/js          # PWA durum katmanı
    ├── fonts/              # Inter woff2
    ├── icons/              # PNG/SVG ikonlar + FA woff2
    └── licenses/           # Üçüncü taraf lisansları
```

## Yayınlama (HTTPS)

Service worker yalnızca **HTTPS** veya **localhost** üzerinde çalışır. `file://` ile çift tıklayarak açmakta PWA/çevrimdışı önbellek devreye girmez.

### GitHub Pages
1. Bu klasörün **içindekileri** bir depo köküne veya `docs/` klasörüne koyun.
2. GitHub → Settings → Pages → kaynağı seçin.
3. Yayınlanan `https://...` adresini açın. İlk ziyaret çevrimiçi olmalıdır.
4. Tarayıcı menüsünden **Ana ekrana ekle / Uygulamayı yükle** seçeneğini kullanın.

Alt dizinde yayınlarsanız (`https://site.github.io/repo/`) `sw.js` kapsamı o alt dizin olur; manifest ve yollar `./` göreli olduğu için çalışır.

### Netlify
Bu klasörü sürükleyip bırakın veya depo olarak bağlayın. `netlify.toml` hazırdır.

### Yerel deneme
```bash
cd yakit-takip-v5-pwa
python3 serve.py 8080
# http://localhost:8080
```

## Çevrimdışı davranış

- **Çalışır:** dolum/gider/yolculuk kayıtları, araçlar, istatistikler, CSV, fotoğraflar (IndexedDB), son kullanılan istasyonlar, manuel istasyon girişi.
- **İnternet ister:** OpenStreetMap karoları, Photon istasyon/adres araması, Google Haritalar gömülü seçici, Open-Meteo hava durumu.
- Üçüncü taraf API yanıtları service worker tarafından önbelleğe **alınmaz**. Kişisel kayıtlarınız zaten cihazınızda kalır.
- İlk başarılı ziyaretten sonra uygulama kabuğu önbelleğe alınır. Çevrimdışı açılışta `index.html` önbellekten servis edilir.

## Güncelleme yayınlama

1. `index.html` veya `assets/` altında bir dosya değiştirin.
2. `sw.js` içindeki `CACHE_VERSION` değerini artırın (ör. `5.0.1`).
3. Aynı URL’e yeniden dağıtın. Kullanıcılar çevrimiçi olduğunda yeni service worker indirilir; uygulama içinde **Yeni sürüm hazır → Yenile** bildirimi çıkar. Kullanıcı yenileyene kadar eski sürüm çalışmaya devam eder.

Tailwind sınıfları değişirse CSS’i yeniden derleyin:
```bash
npx tailwindcss@3.4.17 -c tailwind.config.js -i input.css -o assets/tailwind.css --minify
```
Bu depoda derleme yapılandırması örneği README’nin sonundadır.

## Gizlilik ve veri

- Kayıtlar `localStorage`, fotoğraflar `IndexedDB` içinde tutulur.
- Konum yalnızca kullanıcı ilgili düğmeye bastığında alınır.
- Service worker kişisel verileri ağa göndermez; yalnızca aynı origin statik dosyaları ve gezinmeyi önbelleğe alır.
- Tarayıcı site verilerini temizlemek kayıtları da siler. CSV yedeği almanız önerilir.

## Bu sürümde olmayan

- Gerçek OCR henüz yok; fiş tarama ekranı bir sonraki tur için ayrılmıştır.
- Harita karoları çevrimdışı önbelleğe alınmaz (OSM kullanım politikası ve tazelik nedeniyle).

## Tailwind derleme örneği

`tailwind.config.js`:
```js
module.exports = {
  content: ['./index.html', './assets/pwa.js'],
  theme: { extend: {} },
  plugins: []
};
```
`input.css`:
```css
@tailwind base;
@tailwind components;
@tailwind utilities;
```
