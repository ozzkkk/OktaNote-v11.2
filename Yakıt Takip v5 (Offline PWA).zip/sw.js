/* Yakıt Takip v5 — Service Worker
 * App shell: sürümlü, kurulumda önceden önbelleğe alınır.
 * Gezinme: network-first, çevrimdışıyken önbellekteki index.html.
 * Aynı origin statik dosyalar: cache-first.
 * Üçüncü taraf API/harita/Google istekleri önbelleğe ALINMAZ (gizlilik + tazelik).
 * Kullanıcı verileri localStorage/IndexedDB'dedir; SW bunlara dokunmaz.
 */
const CACHE_VERSION = '5.0.0';
const SHELL_CACHE = `yakit-takip-shell-${CACHE_VERSION}`;
const RUNTIME_CACHE = `yakit-takip-runtime-${CACHE_VERSION}`;
const CACHE_PREFIX = 'yakit-takip-';

const APP_SHELL = [
  './',
  './index.html',
  './manifest.webmanifest',
  './assets/tailwind.css',
  './assets/fonts.css',
  './assets/icons.css',
  './assets/leaflet.css',
  './assets/pwa.css',
  './assets/leaflet.js',
  './assets/pwa.js',
  './assets/fonts/inter-latin.woff2',
  './assets/fonts/inter-latin-ext.woff2',
  './assets/icons/fa-solid-subset.woff2',
  './assets/icons/fa-brands-subset.woff2',
  './assets/icons/favicon.svg',
  './assets/icons/icon-192.png',
  './assets/icons/icon-512.png',
  './assets/icons/icon-maskable-512.png',
  './assets/icons/apple-touch-icon.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(SHELL_CACHE);
    await cache.addAll(APP_SHELL);
    // Yeni sürüm hemen devreye girmez; kullanıcıya "yenile" seçeneği gösterilir.
  })());
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(
      keys
        .filter((key) => key.startsWith(CACHE_PREFIX) && key !== SHELL_CACHE && key !== RUNTIME_CACHE)
        .map((key) => caches.delete(key))
    );
    await self.clients.claim();
  })());
});

function isNavigationRequest(request) {
  if (request.mode === 'navigate') return true;
  const accept = request.headers.get('accept') || '';
  return request.destination === '' && accept.includes('text/html');
}

async function handleNavigation(request) {
  try {
    const response = await fetch(request);
    if (response && response.ok) {
      const cache = await caches.open(SHELL_CACHE);
      // Tek sayfa uygulaması: her başarılı gezinmeyi kabuk olarak sakla.
      await cache.put('./index.html', response.clone());
    }
    return response;
  } catch (err) {
    const cached =
      (await caches.match(request)) ||
      (await caches.match('./index.html')) ||
      (await caches.match('./'));
    if (cached) return cached;
    return new Response(
      '<!doctype html><html lang="tr"><meta charset="utf-8"><title>Çevrimdışı</title><body style="font-family:system-ui;padding:2rem"><h1>Çevrimdışı</h1><p>Uygulama henüz önbelleğe alınmadı. İnternet bağlantısıyla bir kez açın.</p></body></html>',
      { status: 503, headers: { 'Content-Type': 'text/html; charset=utf-8' } }
    );
  }
}

async function handleStatic(request) {
  const cached = await caches.match(request);
  if (cached) return cached;
  try {
    const response = await fetch(request);
    if (response && response.ok && response.type === 'basic') {
      const cache = await caches.open(RUNTIME_CACHE);
      await cache.put(request, response.clone());
    }
    return response;
  } catch (err) {
    return new Response('', { status: 504, statusText: 'Gateway Timeout (offline)' });
  }
}

self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET') return;
  if (request.headers.has('range')) return;

  let url;
  try { url = new URL(request.url); } catch (e) { return; }
  if (url.protocol !== 'http:' && url.protocol !== 'https:') return;

  if (isNavigationRequest(request)) {
    if (url.origin !== self.location.origin) return;
    event.respondWith(handleNavigation(request));
    return;
  }

  if (url.origin === self.location.origin) {
    event.respondWith(handleStatic(request));
    return;
  }

  // Üçüncü taraf istekler (Photon, OSM tiles, Google Maps, Open-Meteo) ağa bırakılır.
});

self.addEventListener('message', (event) => {
  const data = event.data || {};
  if (data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  } else if (data.type === 'GET_VERSION') {
    const port = event.ports && event.ports[0];
    if (port) port.postMessage({ version: CACHE_VERSION, shell: SHELL_CACHE, runtime: RUNTIME_CACHE });
  } else if (data.type === 'CLEAR_RUNTIME') {
    event.waitUntil(caches.delete(RUNTIME_CACHE));
  }
});
